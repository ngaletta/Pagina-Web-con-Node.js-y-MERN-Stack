const Sucursales = () => {
  return (
    <div>
      <h1>Sucursales</h1>
      <iframe
        src="https://www.google.com/maps/d/embed?mid=1P6Po38cBrwKswzRxFq9n39T2bB6Xa1Q&ehbc=2E312F"
        width="640"
        height="480"
      ></iframe>{" "}
    </div>
  );
};

export default Sucursales;
