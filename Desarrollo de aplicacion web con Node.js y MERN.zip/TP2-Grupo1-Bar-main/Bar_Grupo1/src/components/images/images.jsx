import React from 'react'

const images = ({ url }) => {
    return (
        <div>

            <img src={url} alt="" />

        </div>
    )
}

export default images