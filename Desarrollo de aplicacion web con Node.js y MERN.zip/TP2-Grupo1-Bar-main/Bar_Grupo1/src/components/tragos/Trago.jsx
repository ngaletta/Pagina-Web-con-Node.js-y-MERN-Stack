
const Trago = ({ trago }) => {
  return (
    
      <div className="menu">
        <h1>{trago.nombre}</h1>
        <h2>Precio: ${trago.precio}</h2>
      </div>
    
  );
};
export default Trago;