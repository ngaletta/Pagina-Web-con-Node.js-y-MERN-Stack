
class Tragos {

    constructor() {

        this.tragos = [
            { nombre: "cerveza", precio: "800", id: 123 },
            { nombre: "fernet", precio: "1200", id: 124 },
            { nombre: "Gancia", precio: "800", id: 125 },
            { nombre: "daiquiri", precio: "1500", id: 126 },
            { nombre: "Mojito", precio: "950", id: 127 },
            { nombre: "Margarita", precio: "1400", id: 128 },
        ]
    }
}

export default Tragos;


