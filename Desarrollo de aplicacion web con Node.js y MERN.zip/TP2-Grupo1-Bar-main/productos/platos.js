
class Platos {

    constructor() {

        this.platos = [
            { nombre: "Hamburguesa triple cheddar", precio: "2400", id: 1 },
            { nombre: "Haburguesa triple carne", precio: "2600", id: 6 },
            { nombre: "Hamburguesa doble bacon", precio: "2600", id: 4 },
            { nombre: "Papas fritas", precio: "1000", id: 2},
            { nombre: "Papas fritas con cheddar", precio: "1500", id: 3 },
            { nombre: "Palitos de mozzarella ", precio: "2100", id: 5 },
            
        ]
    }
}

export default Platos;